﻿using IPO2_P4_ControlUsuario2026;
using PokemonGrupal.Pokedex; 
using System.Collections.Generic;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media;


namespace PokemonGrupal
{
   
    public sealed partial class PokedexPage : Page
    {
        public PokedexPage()
        {
            this.InitializeComponent();
            CargarCuadricula();
        }

        private void CargarCuadricula()
        {
            // 1. Creamos la lista de Pokémon
            var lista = new List<iPokemon>
            {
                new RotomXYZ(),
                new RotomXYZ(),
                new RotomXYZ(),
                new RotomXYZ(),               
                new RotomXYZ(),
                new RotomXYZ(),
                new RotomXYZ(),
                new RotomXYZ(),
                new RotomXYZ(),
               // new FennekinRRM(), 
                new RotomXYZ()
            };

            // 2. Recorremos la lista para dibujarlos en el XAML
            for (int i = 0; i < lista.Count; i++)
            {
                var poke = lista[i];

                // Preparamos el Pokémon (ocultamos vida y activamos animación base)
                poke.verFilaVida(false);
                poke.verFilaEnergia(false);
                poke.activarAniIdle(true);

                // 3. EL VIEWBOX: Encoger dibujo
                Viewbox escala = new Viewbox
                {
                    Child = (UIElement)poke,
                    Stretch = Stretch.Uniform,
                    Margin = new Thickness(15)
                };

                // 4. Creamos el recuadro cuadrado del pokemon en la pokedex
                Border tarjeta = new Border
                {
                    Height = 220,
                    Margin = new Thickness(10), // Separación entre recuadros
                    HorizontalAlignment = HorizontalAlignment.Stretch, // Obliga a la tarjeta a llenar su mitad
                    Background = new SolidColorBrush(Windows.UI.Colors.DimGray),
                    CornerRadius = new CornerRadius(12),
                    Child = escala
                };

                // 5. Numero de columnas de la pokedex)
                int fila = i / 2;
                int columna = i % 2;

                // Si la fila que toca no existe en el Grid, la creamos sobre la marcha
                if (gridPokemons.RowDefinitions.Count <= fila)
                {
                    gridPokemons.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                }

                // 6. Colocamos la tarjeta en la celda correspondiente y la añadimos
                Grid.SetRow(tarjeta, fila);
                Grid.SetColumn(tarjeta, columna);

                gridPokemons.Children.Add(tarjeta);
            }
        }
    }
}
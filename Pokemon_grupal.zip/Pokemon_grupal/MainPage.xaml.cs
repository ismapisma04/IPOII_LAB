﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.UI.Core; 
using Microsoft.Toolkit.Uwp.Notifications; 

namespace PokemonGrupal
{
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();

            // evento de teclado para detectar la tecla 'N'
            Window.Current.CoreWindow.KeyDown += CoreWindow_KeyDown;
        }

        // Al pulsar "n" se manda una notificación de windows
        private void CoreWindow_KeyDown(CoreWindow sender, KeyEventArgs args)
        {
            // Si el usuario pulsa la tecla N, lanzamos la notificación
            if (args.VirtualKey == Windows.System.VirtualKey.N)
            {
                LanzarNotificacion();
            }
        }

        private void LanzarNotificacion()
        {
            // Ejemplo de notificación
            new ToastContentBuilder()
                .AddArgument("action", "Favoritos")
                .AddArgument("conversationId", 9813)
                .AddText("Rayquaza te saluda")
                .AddText("Puedes ver más información en IPOkemon")
                .AddInlineImage(new Uri("ms-appx:///Assets/rayquaza.png"))
                .AddAppLogoOverride(new Uri("ms-appx:///Assets/rayquaza.png"), ToastGenericAppLogoCrop.Circle)
                .Show();
        }

        

        private void btnMenu_Click(object sender, RoutedEventArgs e)
        {
            // Abre o cierra el panel lateral
            svMenu.IsPaneOpen = !svMenu.IsPaneOpen;
        }

        private void irInicio(object sender, RoutedEventArgs e)
        {
            txtTitulo.Text = "Inicio";
 
        }

        private void irPokeDex(object sender, RoutedEventArgs e)
        {
            txtTitulo.Text = "PokeDex";
            // Esto carga la página de la cuadrícula dentro del hueco de la derecha
            fmMain.Navigate(typeof(PokedexPage));

        }

        private void irCombate(object sender, RoutedEventArgs e)
        {
            txtTitulo.Text = "Combate";
          
        }
        private void irMisPokemon(object sender, RoutedEventArgs e)
        {
            txtTitulo.Text = "Mis Pokemon";
        }

        private void irAcercaDe(object sender, RoutedEventArgs e)
        {
            txtTitulo.Text = "Acerca de";
        }
    }
}